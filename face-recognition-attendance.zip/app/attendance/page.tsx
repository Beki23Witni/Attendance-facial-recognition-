"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { ArrowLeft, UserCheck, Loader2, RefreshCw } from "lucide-react"
import { WebcamCapture } from "@/components/webcam-capture"
import { FaceDetection } from "@/components/face-detection"
import { loadModels, createFaceDescriptor, compareFaces } from "@/lib/face-recognition"

export default function AttendancePage() {
  const { toast } = useToast()
  const [capturedImage, setCapturedImage] = useState<string | null>(null)
  const [recognizedUser, setRecognizedUser] = useState<any | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [modelsLoaded, setModelsLoaded] = useState(false)
  const [attendanceRecords, setAttendanceRecords] = useState<any[]>([])
  const [recentAttendance, setRecentAttendance] = useState<any[]>([])

  useEffect(() => {
    const initModels = async () => {
      try {
        await loadModels()
        setModelsLoaded(true)
      } catch (error) {
        console.error("Error loading face-api models:", error)
        toast({
          title: "Error",
          description: "Failed to load face recognition models. Please refresh the page.",
          variant: "destructive",
        })
      }
    }

    initModels()

    // Load existing attendance records
    const existingRecords = JSON.parse(localStorage.getItem("attendanceRecords") || "[]")
    setAttendanceRecords(existingRecords)

    // Get today's records for the recent list
    const today = new Date().toISOString().split("T")[0]
    const todayRecords = existingRecords
      .filter((record: any) => record.timestamp.startsWith(today))
      .sort((a: any, b: any) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 5)

    setRecentAttendance(todayRecords)
  }, [toast])

  const handleCapture = (imageSrc: string) => {
    setCapturedImage(imageSrc)
    setRecognizedUser(null)
  }

  const handleRecognizeFace = async () => {
    if (!capturedImage) return

    setIsProcessing(true)
    try {
      // Get the face descriptor from the captured image
      const descriptor = await createFaceDescriptor(capturedImage)

      if (!descriptor) {
        toast({
          title: "Error",
          description: "No face detected or multiple faces found. Please try again.",
          variant: "destructive",
        })
        setIsProcessing(false)
        return
      }

      // Get registered users from localStorage
      const users = JSON.parse(localStorage.getItem("users") || "[]")

      if (users.length === 0) {
        toast({
          title: "Error",
          description: "No users registered in the system. Please register users first.",
          variant: "destructive",
        })
        setIsProcessing(false)
        return
      }

      // Compare the captured face with registered faces
      let matchedUser = null
      let highestSimilarity = 0

      for (const user of users) {
        // Convert stored array back to Float32Array
        const storedDescriptor = new Float32Array(user.faceDescriptor)
        const similarity = compareFaces(descriptor, storedDescriptor)

        if (similarity > 0.6 && similarity > highestSimilarity) {
          highestSimilarity = similarity
          matchedUser = { ...user, similarity }
        }
      }

      if (matchedUser) {
        // Check if user already marked attendance today
        const today = new Date().toISOString().split("T")[0]
        const alreadyMarked = attendanceRecords.some(
          (record) => record.userId === matchedUser.id && record.timestamp.startsWith(today),
        )

        if (alreadyMarked) {
          toast({
            title: "Already Marked",
            description: `${matchedUser.name} has already been marked present today.`,
          })
          setRecognizedUser({ ...matchedUser, alreadyMarked: true })
        } else {
          // Mark attendance
          const timestamp = new Date().toISOString()
          const newRecord = {
            userId: matchedUser.id,
            userName: matchedUser.name,
            userRole: matchedUser.role,
            timestamp,
            similarity: highestSimilarity.toFixed(2),
          }

          const updatedRecords = [...attendanceRecords, newRecord]
          localStorage.setItem("attendanceRecords", JSON.stringify(updatedRecords))
          setAttendanceRecords(updatedRecords)

          // Update recent attendance list
          setRecentAttendance([newRecord, ...recentAttendance].slice(0, 5))

          toast({
            title: "Success",
            description: `Attendance marked for ${matchedUser.name}`,
          })
          setRecognizedUser({ ...matchedUser, alreadyMarked: false })
        }
      } else {
        toast({
          title: "Not Recognized",
          description: "Face not recognized. Please try again or register the user.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error recognizing face:", error)
      toast({
        title: "Error",
        description: "Failed to process face. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp)
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Button variant="outline" asChild>
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
          </Link>
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Mark Attendance</CardTitle>
            <CardDescription>Use face recognition to mark attendance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {modelsLoaded ? (
                <WebcamCapture onCapture={handleCapture} />
              ) : (
                <div className="flex h-[300px] items-center justify-center rounded-md border border-dashed">
                  <div className="flex flex-col items-center space-y-2 text-center">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">Loading face recognition models...</p>
                  </div>
                </div>
              )}

              {capturedImage && (
                <div className="space-y-2">
                  <div className="relative overflow-hidden rounded-md">
                    <img src={capturedImage || "/placeholder.svg"} alt="Captured face" className="h-auto w-full" />
                    <FaceDetection imageSrc={capturedImage} />
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" onClick={() => setCapturedImage(null)} className="w-1/2">
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Retake
                    </Button>
                    <Button onClick={handleRecognizeFace} disabled={isProcessing} className="w-1/2">
                      {isProcessing ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <UserCheck className="mr-2 h-4 w-4" />
                          Recognize
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              )}

              {recognizedUser && (
                <div className={`rounded-md p-4 ${recognizedUser.alreadyMarked ? "bg-yellow-50" : "bg-green-50"}`}>
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <svg
                        className={`h-5 w-5 ${recognizedUser.alreadyMarked ? "text-yellow-400" : "text-green-400"}`}
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <h3
                        className={`text-sm font-medium ${recognizedUser.alreadyMarked ? "text-yellow-800" : "text-green-800"}`}
                      >
                        {recognizedUser.alreadyMarked ? "Already Marked Present" : "Attendance Marked Successfully"}
                      </h3>
                      <div
                        className={`mt-2 text-sm ${recognizedUser.alreadyMarked ? "text-yellow-700" : "text-green-700"}`}
                      >
                        <p>
                          <strong>Name:</strong> {recognizedUser.name}
                        </p>
                        <p>
                          <strong>ID:</strong> {recognizedUser.id}
                        </p>
                        <p>
                          <strong>Role:</strong> {recognizedUser.role}
                        </p>
                        <p>
                          <strong>Match Confidence:</strong> {(recognizedUser.similarity * 100).toFixed(0)}%
                        </p>
                        <p>
                          <strong>Time:</strong> {new Date().toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
          <CardFooter>
            <p className="text-xs text-muted-foreground">
              Position your face clearly in the camera frame for best recognition results.
            </p>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Attendance</CardTitle>
            <CardDescription>Today&apos;s attendance records</CardDescription>
          </CardHeader>
          <CardContent>
            {recentAttendance.length > 0 ? (
              <div className="space-y-4">
                {recentAttendance.map((record, index) => (
                  <div key={index} className="flex items-center justify-between rounded-md border p-3">
                    <div className="flex items-center space-x-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                        <UserCheck className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">{record.userName}</p>
                        <p className="text-xs text-muted-foreground">
                          {record.userRole} • ID: {record.userId}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{formatTime(record.timestamp)}</p>
                      <p className="text-xs text-muted-foreground">
                        Match: {Number.parseInt(record.similarity) * 100}%
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex h-[200px] items-center justify-center rounded-md border border-dashed">
                <div className="text-center">
                  <p className="text-sm font-medium">No attendance records today</p>
                  <p className="text-xs text-muted-foreground">Records will appear here after marking attendance</p>
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter>
            <Button asChild variant="outline" className="w-full">
              <Link href="/records">View All Records</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
