"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { ArrowLeft, Download, Search, Calendar, Filter, X } from "lucide-react"

export default function RecordsPage() {
  const { toast } = useToast()
  const [attendanceRecords, setAttendanceRecords] = useState<any[]>([])
  const [filteredRecords, setFilteredRecords] = useState<any[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [dateFilter, setDateFilter] = useState("")
  const [roleFilter, setRoleFilter] = useState("")

  useEffect(() => {
    // Load attendance records from localStorage
    const records = JSON.parse(localStorage.getItem("attendanceRecords") || "[]")
    // Sort by timestamp (newest first)
    records.sort((a: any, b: any) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    setAttendanceRecords(records)
    setFilteredRecords(records)
  }, [])

  useEffect(() => {
    let results = [...attendanceRecords]

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      results = results.filter(
        (record) => record.userName.toLowerCase().includes(query) || record.userId.toLowerCase().includes(query),
      )
    }

    // Apply date filter
    if (dateFilter) {
      results = results.filter((record) => record.timestamp.startsWith(dateFilter))
    }

    // Apply role filter
    if (roleFilter) {
      results = results.filter((record) => record.userRole === roleFilter)
    }

    setFilteredRecords(results)
  }, [searchQuery, dateFilter, roleFilter, attendanceRecords])

  const handleExportCSV = () => {
    if (filteredRecords.length === 0) {
      toast({
        title: "No Records",
        description: "There are no records to export.",
        variant: "destructive",
      })
      return
    }

    // Create CSV content
    const headers = ["ID", "Name", "Role", "Date", "Time", "Match Confidence"]
    const csvRows = [headers.join(",")]

    filteredRecords.forEach((record) => {
      const date = new Date(record.timestamp)
      const dateStr = date.toLocaleDateString()
      const timeStr = date.toLocaleTimeString()

      const row = [
        record.userId,
        `"${record.userName}"`, // Wrap in quotes to handle names with commas
        record.userRole,
        dateStr,
        timeStr,
        `${Number.parseInt(record.similarity) * 100}%`,
      ]

      csvRows.push(row.join(","))
    })

    const csvContent = csvRows.join("\n")

    // Create and download the CSV file
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", `attendance_records_${new Date().toISOString().split("T")[0]}.csv`)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast({
      title: "Export Successful",
      description: `Exported ${filteredRecords.length} records to CSV.`,
    })
  }

  const formatDateTime = (timestamp: string) => {
    const date = new Date(timestamp)
    return `${date.toLocaleDateString()} ${date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
  }

  const clearFilters = () => {
    setSearchQuery("")
    setDateFilter("")
    setRoleFilter("")
  }

  const uniqueRoles = [...new Set(attendanceRecords.map((record) => record.userRole))]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Button variant="outline" asChild>
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col space-y-2 md:flex-row md:items-center md:justify-between md:space-y-0">
            <div>
              <CardTitle>Attendance Records</CardTitle>
              <CardDescription>View and export attendance history</CardDescription>
            </div>
            <Button onClick={handleExportCSV}>
              <Download className="mr-2 h-4 w-4" />
              Export to CSV
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex flex-col space-y-2 md:flex-row md:space-x-2 md:space-y-0">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name or ID..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="relative md:w-48">
                <Calendar className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="date"
                  className="pl-8"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                />
              </div>
              <div className="relative md:w-48">
                <Filter className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <select
                  className="flex h-10 w-full rounded-md border border-input bg-background px-8 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  value={roleFilter}
                  onChange={(e) => setRoleFilter(e.target.value)}
                >
                  <option value="">All Roles</option>
                  {uniqueRoles.map((role) => (
                    <option key={role} value={role}>
                      {role.charAt(0).toUpperCase() + role.slice(1)}
                    </option>
                  ))}
                </select>
              </div>
              {(searchQuery || dateFilter || roleFilter) && (
                <Button variant="ghost" size="icon" onClick={clearFilters}>
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>

            <div className="rounded-md border">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/50 font-medium">
                      <th className="px-4 py-3 text-left">Name</th>
                      <th className="px-4 py-3 text-left">ID</th>
                      <th className="px-4 py-3 text-left">Role</th>
                      <th className="px-4 py-3 text-left">Date & Time</th>
                      <th className="px-4 py-3 text-left">Match</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredRecords.length > 0 ? (
                      filteredRecords.map((record, index) => (
                        <tr key={index} className="border-b">
                          <td className="px-4 py-3">{record.userName}</td>
                          <td className="px-4 py-3">{record.userId}</td>
                          <td className="px-4 py-3">
                            <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium bg-primary/10 text-primary">
                              {record.userRole}
                            </span>
                          </td>
                          <td className="px-4 py-3">{formatDateTime(record.timestamp)}</td>
                          <td className="px-4 py-3">{Number.parseInt(record.similarity) * 100}%</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={5} className="px-4 py-8 text-center">
                          <p className="text-muted-foreground">No attendance records found</p>
                          {(searchQuery || dateFilter || roleFilter) && (
                            <p className="mt-1 text-xs text-muted-foreground">Try adjusting your search filters</p>
                          )}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                Showing {filteredRecords.length} of {attendanceRecords.length} records
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
