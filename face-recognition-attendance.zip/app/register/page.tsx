"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { ArrowLeft, Camera, Save, Loader2 } from "lucide-react"
import { WebcamCapture } from "@/components/webcam-capture"
import { FaceDetection } from "@/components/face-detection"
import { loadModels, createFaceDescriptor } from "@/lib/face-recognition"

export default function RegisterPage() {
  const { toast } = useToast()
  const [name, setName] = useState("")
  const [id, setId] = useState("")
  const [role, setRole] = useState("student")
  const [capturedImage, setCapturedImage] = useState<string | null>(null)
  const [faceDescriptor, setFaceDescriptor] = useState<Float32Array | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [modelsLoaded, setModelsLoaded] = useState(false)
  const [step, setStep] = useState(1)

  useEffect(() => {
    const initModels = async () => {
      try {
        await loadModels()
        setModelsLoaded(true)
      } catch (error) {
        console.error("Error loading face-api models:", error)
        toast({
          title: "Error",
          description: "Failed to load face recognition models. Please refresh the page.",
          variant: "destructive",
        })
      }
    }

    initModels()
  }, [toast])

  const handleCapture = (imageSrc: string) => {
    setCapturedImage(imageSrc)
    setStep(2)
  }

  const handleProcessFace = async () => {
    if (!capturedImage) return

    setIsProcessing(true)
    try {
      const descriptor = await createFaceDescriptor(capturedImage)
      if (descriptor) {
        setFaceDescriptor(descriptor)
        toast({
          title: "Success",
          description: "Face processed successfully!",
        })
        setStep(3)
      } else {
        toast({
          title: "Error",
          description: "No face detected or multiple faces found. Please try again.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error processing face:", error)
      toast({
        title: "Error",
        description: "Failed to process face. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const handleRegister = () => {
    if (!name || !id || !faceDescriptor) {
      toast({
        title: "Error",
        description: "Please fill all fields and capture a face image.",
        variant: "destructive",
      })
      return
    }

    // Get existing users or initialize empty array
    const existingUsers = JSON.parse(localStorage.getItem("users") || "[]")

    // Check if ID already exists
    if (existingUsers.some((user: any) => user.id === id)) {
      toast({
        title: "Error",
        description: "User ID already exists. Please use a different ID.",
        variant: "destructive",
      })
      return
    }

    // Create new user object
    const newUser = {
      id,
      name,
      role,
      faceDescriptor: Array.from(faceDescriptor),
      registeredAt: new Date().toISOString(),
    }

    // Add to existing users and save to localStorage
    existingUsers.push(newUser)
    localStorage.setItem("users", JSON.stringify(existingUsers))

    toast({
      title: "Success",
      description: `User ${name} registered successfully!`,
    })

    // Reset form
    setName("")
    setId("")
    setRole("student")
    setCapturedImage(null)
    setFaceDescriptor(null)
    setStep(1)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Button variant="outline" asChild>
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
          </Link>
        </Button>
      </div>

      <div className="mx-auto max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle>Register New User</CardTitle>
            <CardDescription>Add a new user to the face recognition system</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {step === 1 && (
                <>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        placeholder="Enter full name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="id">ID Number</Label>
                      <Input id="id" placeholder="Enter ID number" value={id} onChange={(e) => setId(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="role">Role</Label>
                      <select
                        id="role"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        value={role}
                        onChange={(e) => setRole(e.target.value)}
                      >
                        <option value="student">Student</option>
                        <option value="teacher">Teacher</option>
                        <option value="staff">Staff</option>
                        <option value="admin">Administrator</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Capture Face Image</Label>
                    {modelsLoaded ? (
                      <WebcamCapture onCapture={handleCapture} />
                    ) : (
                      <div className="flex h-[300px] items-center justify-center rounded-md border border-dashed">
                        <div className="flex flex-col items-center space-y-2 text-center">
                          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                          <p className="text-sm text-muted-foreground">Loading face recognition models...</p>
                        </div>
                      </div>
                    )}
                  </div>
                </>
              )}

              {step === 2 && capturedImage && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Verify Face Image</Label>
                    <div className="relative overflow-hidden rounded-md">
                      <img src={capturedImage || "/placeholder.svg"} alt="Captured face" className="h-auto w-full" />
                      <FaceDetection imageSrc={capturedImage} />
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setCapturedImage(null)
                        setStep(1)
                      }}
                    >
                      Retake
                    </Button>
                    <Button onClick={handleProcessFace} disabled={isProcessing}>
                      {isProcessing ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <Camera className="mr-2 h-4 w-4" />
                          Process Face
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-4">
                  <div className="rounded-md bg-green-50 p-4">
                    <div className="flex">
                      <div className="flex-shrink-0">
                        <svg className="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor">
                          <path
                            fillRule="evenodd"
                            d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                            clipRule="evenodd"
                          />
                        </svg>
                      </div>
                      <div className="ml-3">
                        <h3 className="text-sm font-medium text-green-800">Face processed successfully</h3>
                        <div className="mt-2 text-sm text-green-700">
                          <p>Face features have been extracted and are ready for registration.</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">Registration Summary</h3>
                    <div className="rounded-md bg-gray-50 p-4">
                      <dl className="grid grid-cols-1 gap-x-4 gap-y-2 sm:grid-cols-2">
                        <div className="sm:col-span-1">
                          <dt className="text-sm font-medium text-gray-500">Name</dt>
                          <dd className="mt-1 text-sm text-gray-900">{name}</dd>
                        </div>
                        <div className="sm:col-span-1">
                          <dt className="text-sm font-medium text-gray-500">ID</dt>
                          <dd className="mt-1 text-sm text-gray-900">{id}</dd>
                        </div>
                        <div className="sm:col-span-1">
                          <dt className="text-sm font-medium text-gray-500">Role</dt>
                          <dd className="mt-1 text-sm text-gray-900">{role}</dd>
                        </div>
                        <div className="sm:col-span-1">
                          <dt className="text-sm font-medium text-gray-500">Face Data</dt>
                          <dd className="mt-1 text-sm text-gray-900">Processed ✓</dd>
                        </div>
                      </dl>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            {step === 3 ? (
              <>
                <Button
                  variant="outline"
                  onClick={() => {
                    setCapturedImage(null)
                    setFaceDescriptor(null)
                    setStep(1)
                  }}
                >
                  Start Over
                </Button>
                <Button onClick={handleRegister}>
                  <Save className="mr-2 h-4 w-4" />
                  Complete Registration
                </Button>
              </>
            ) : (
              <div className="ml-auto">
                {step > 1 && (
                  <Button variant="outline" onClick={() => setStep(step - 1)} className="mr-2">
                    Previous
                  </Button>
                )}
              </div>
            )}
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
