"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import { ArrowLeft, Save, Trash2, AlertTriangle, Users, Database, RefreshCw } from "lucide-react"

export default function SettingsPage() {
  const { toast } = useToast()
  const [matchThreshold, setMatchThreshold] = useState(0.6)
  const [preventDuplicates, setPreventDuplicates] = useState(true)
  const [autoExport, setAutoExport] = useState(false)
  const [exportTime, setExportTime] = useState("17:00")
  const [userCount, setUserCount] = useState(0)
  const [recordCount, setRecordCount] = useState(0)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<"users" | "records" | "all" | null>(null)

  useEffect(() => {
    // Load settings from localStorage
    const settings = JSON.parse(localStorage.getItem("systemSettings") || "{}")
    if (settings.matchThreshold) setMatchThreshold(settings.matchThreshold)
    if (settings.preventDuplicates !== undefined) setPreventDuplicates(settings.preventDuplicates)
    if (settings.autoExport !== undefined) setAutoExport(settings.autoExport)
    if (settings.exportTime) setExportTime(settings.exportTime)

    // Count users and records
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const records = JSON.parse(localStorage.getItem("attendanceRecords") || "[]")
    setUserCount(users.length)
    setRecordCount(records.length)
  }, [])

  const handleSaveSettings = () => {
    const settings = {
      matchThreshold,
      preventDuplicates,
      autoExport,
      exportTime,
    }

    localStorage.setItem("systemSettings", JSON.stringify(settings))

    toast({
      title: "Settings Saved",
      description: "Your system settings have been updated successfully.",
    })
  }

  const handleDelete = (target: "users" | "records" | "all") => {
    setDeleteTarget(target)
    setShowDeleteConfirm(true)
  }

  const confirmDelete = () => {
    if (deleteTarget === "users") {
      localStorage.setItem("users", "[]")
      setUserCount(0)
      toast({
        title: "Users Deleted",
        description: "All registered users have been deleted from the system.",
      })
    } else if (deleteTarget === "records") {
      localStorage.setItem("attendanceRecords", "[]")
      setRecordCount(0)
      toast({
        title: "Records Deleted",
        description: "All attendance records have been deleted from the system.",
      })
    } else if (deleteTarget === "all") {
      localStorage.setItem("users", "[]")
      localStorage.setItem("attendanceRecords", "[]")
      setUserCount(0)
      setRecordCount(0)
      toast({
        title: "System Reset",
        description: "All users and records have been deleted from the system.",
      })
    }

    setShowDeleteConfirm(false)
    setDeleteTarget(null)
  }

  const cancelDelete = () => {
    setShowDeleteConfirm(false)
    setDeleteTarget(null)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Button variant="outline" asChild>
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
          </Link>
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>System Settings</CardTitle>
              <CardDescription>Configure how the face recognition system works</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="threshold">Face Match Threshold ({(matchThreshold * 100).toFixed(0)}%)</Label>
                <div className="flex items-center space-x-2">
                  <span className="text-xs">50%</span>
                  <Input
                    id="threshold"
                    type="range"
                    min="0.5"
                    max="0.9"
                    step="0.01"
                    value={matchThreshold}
                    onChange={(e) => setMatchThreshold(Number.parseFloat(e.target.value))}
                    className="flex-1"
                  />
                  <span className="text-xs">90%</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Higher values require closer face matches but may reduce false positives.
                </p>
              </div>

              <div className="flex items-center justify-between space-x-2">
                <div className="space-y-0.5">
                  <Label htmlFor="duplicates">Prevent Duplicate Entries</Label>
                  <p className="text-xs text-muted-foreground">
                    Prevent the same person from being marked present multiple times per day
                  </p>
                </div>
                <Switch id="duplicates" checked={preventDuplicates} onCheckedChange={setPreventDuplicates} />
              </div>

              <div className="flex items-center justify-between space-x-2">
                <div className="space-y-0.5">
                  <Label htmlFor="autoExport">Automatic Daily Export</Label>
                  <p className="text-xs text-muted-foreground">
                    Automatically export attendance records at a specified time
                  </p>
                </div>
                <Switch id="autoExport" checked={autoExport} onCheckedChange={setAutoExport} />
              </div>

              {autoExport && (
                <div className="space-y-2">
                  <Label htmlFor="exportTime">Export Time</Label>
                  <Input
                    id="exportTime"
                    type="time"
                    value={exportTime}
                    onChange={(e) => setExportTime(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Time when the system will automatically export the day&apos;s attendance records
                  </p>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveSettings}>
                <Save className="mr-2 h-4 w-4" />
                Save Settings
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>System Information</CardTitle>
              <CardDescription>Current system status and statistics</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between rounded-md border p-3">
                <div className="flex items-center space-x-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                    <Users className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Registered Users</p>
                    <p className="text-xs text-muted-foreground">Total users in the system</p>
                  </div>
                </div>
                <div className="text-2xl font-bold">{userCount}</div>
              </div>

              <div className="flex items-center justify-between rounded-md border p-3">
                <div className="flex items-center space-x-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                    <Database className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Attendance Records</p>
                    <p className="text-xs text-muted-foreground">Total attendance entries</p>
                  </div>
                </div>
                <div className="text-2xl font-bold">{recordCount}</div>
              </div>

              <div className="flex items-center justify-between rounded-md border p-3">
                <div className="flex items-center space-x-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                    <RefreshCw className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">System Version</p>
                    <p className="text-xs text-muted-foreground">Current software version</p>
                  </div>
                </div>
                <div className="font-medium">v1.0.0</div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Data Management</CardTitle>
              <CardDescription>Manage system data and perform maintenance</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-md border p-4">
                <h3 className="text-lg font-medium">Delete Registered Users</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Remove all registered users from the system. This action cannot be undone.
                </p>
                <Button variant="destructive" className="mt-4" onClick={() => handleDelete("users")}>
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete All Users
                </Button>
              </div>

              <div className="rounded-md border p-4">
                <h3 className="text-lg font-medium">Delete Attendance Records</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Remove all attendance records from the system. This action cannot be undone.
                </p>
                <Button variant="destructive" className="mt-4" onClick={() => handleDelete("records")}>
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete All Records
                </Button>
              </div>

              <div className="rounded-md border p-4">
                <h3 className="text-lg font-medium">Factory Reset</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Reset the entire system to its default state. All users and records will be deleted.
                </p>
                <Button variant="destructive" className="mt-4" onClick={() => handleDelete("all")}>
                  <Trash2 className="mr-2 h-4 w-4" />
                  Reset System
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>System Requirements</CardTitle>
              <CardDescription>Recommended hardware and software specifications</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-blue-500"></div>
                  <span className="text-sm">
                    <strong>Camera:</strong> HD webcam or external camera with at least 720p resolution
                  </span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-blue-500"></div>
                  <span className="text-sm">
                    <strong>Processor:</strong> Intel Core i3 or equivalent (i5 or higher recommended)
                  </span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-blue-500"></div>
                  <span className="text-sm">
                    <strong>Memory:</strong> Minimum 4GB RAM (8GB or higher recommended)
                  </span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-blue-500"></div>
                  <span className="text-sm">
                    <strong>Browser:</strong> Latest version of Chrome, Firefox, or Edge
                  </span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-blue-500"></div>
                  <span className="text-sm">
                    <strong>Internet:</strong> Required for initial setup, optional for ongoing use
                  </span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-blue-500"></div>
                  <span className="text-sm">
                    <strong>Lighting:</strong> Well-lit environment for optimal face recognition
                  </span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>

      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="flex items-center text-red-600">
                <AlertTriangle className="mr-2 h-5 w-5" />
                Confirm Deletion
              </CardTitle>
              <CardDescription>This action cannot be undone. Please confirm.</CardDescription>
            </CardHeader>
            <CardContent>
              <p>
                {deleteTarget === "users" && "You are about to delete all registered users from the system."}
                {deleteTarget === "records" && "You are about to delete all attendance records from the system."}
                {deleteTarget === "all" && "You are about to reset the entire system to its default state."}
              </p>
              <p className="mt-2 font-medium">Are you sure you want to continue?</p>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={cancelDelete}>
                Cancel
              </Button>
              <Button variant="destructive" onClick={confirmDelete}>
                Yes, Delete
              </Button>
            </CardFooter>
          </Card>
        </div>
      )}
    </div>
  )
}
