"use client"

import { useEffect, useRef, useState } from "react"
import { Loader2 } from "lucide-react"
import { detectFaces } from "@/lib/face-recognition"

interface FaceDetectionProps {
  imageSrc: string
}

export function FaceDetection({ imageSrc }: FaceDetectionProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isProcessing, setIsProcessing] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const processImage = async () => {
      if (!canvasRef.current || !imageSrc) return

      setIsProcessing(true)
      setError(null)

      try {
        const canvas = canvasRef.current
        const ctx = canvas.getContext("2d")

        if (!ctx) {
          setError("Canvas context not available")
          return
        }

        // Load the image
        const img = new Image()
        img.crossOrigin = "anonymous"
        img.src = imageSrc

        img.onload = async () => {
          // Set canvas dimensions to match image
          canvas.width = img.width
          canvas.height = img.height

          // Draw the image on the canvas
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height)

          // Detect faces
          const detections = await detectFaces(imageSrc)

          if (detections && detections.length > 0) {
            // Draw rectangles around detected faces
            ctx.strokeStyle = "#4ade80" // green-400
            ctx.lineWidth = 3

            detections.forEach((detection) => {
              // Check if box exists and has the required properties
              if (detection.box && typeof detection.box.x === "number") {
                const { x, y, width, height } = detection.box
                ctx.strokeRect(x, y, width, height)
              }
            })
          }

          setIsProcessing(false)
        }

        img.onerror = () => {
          setError("Failed to load image")
          setIsProcessing(false)
        }
      } catch (err) {
        console.error("Error in face detection:", err)
        setError("Face detection failed")
        setIsProcessing(false)
      }
    }

    processImage()
  }, [imageSrc])

  return (
    <div className="relative">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />

      {isProcessing && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/20">
          <div className="rounded-md bg-white p-2">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        </div>
      )}

      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/20">
          <div className="rounded-md bg-white p-2 text-sm text-red-500">{error}</div>
        </div>
      )}
    </div>
  )
}
