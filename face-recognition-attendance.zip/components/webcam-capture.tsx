"use client"

import { useState, useRef, useCallback, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Camera, RefreshCw } from "lucide-react"
import { useMobile } from "@/hooks/use-mobile"

interface WebcamCaptureProps {
  onCapture: (imageSrc: string) => void
}

export function WebcamCapture({ onCapture }: WebcamCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [isCapturing, setIsCapturing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const isMobile = useMobile()

  const startCamera = useCallback(async () => {
    // First ensure any existing streams are properly stopped
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
      setStream(null)
    }

    try {
      setError(null)
      const constraints = {
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: isMobile ? "user" : "user",
        },
      }

      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints)

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream
        // Wait for video to be ready
        videoRef.current.onloadedmetadata = () => {
          setIsCapturing(true)
        }
      }

      setStream(mediaStream)
    } catch (err) {
      console.error("Error accessing camera:", err)
      setError("Could not access camera. Please ensure camera permissions are granted.")
      setIsCapturing(false)
    }
  }, [isMobile, stream])

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
      setStream(null)
    }
    setIsCapturing(false)
  }, [stream])

  const captureImage = useCallback(() => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current
      const canvas = canvasRef.current
      const context = canvas.getContext("2d")

      if (context) {
        // Set canvas dimensions to match video
        canvas.width = video.videoWidth
        canvas.height = video.videoHeight

        // Draw the current video frame to the canvas
        context.drawImage(video, 0, 0, canvas.width, canvas.height)

        // Convert canvas to data URL
        const imageSrc = canvas.toDataURL("image/png")

        // Pass the captured image to the parent component
        onCapture(imageSrc)

        // Stop the camera after capturing
        stopCamera()
      }
    }
  }, [onCapture, stopCamera])

  useEffect(() => {
    // Only start camera on initial mount, not on every render
    let mounted = true

    const initCamera = async () => {
      try {
        if (!mounted) return

        setError(null)
        const constraints = {
          video: {
            width: { ideal: 640 },
            height: { ideal: 480 },
            facingMode: isMobile ? "user" : "user",
          },
        }

        const mediaStream = await navigator.mediaDevices.getUserMedia(constraints)

        // Check if component is still mounted before updating state
        if (!mounted) {
          mediaStream.getTracks().forEach((track) => track.stop())
          return
        }

        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream
          // Wait for video to be ready
          videoRef.current.onloadedmetadata = () => {
            if (!mounted) return
            setIsCapturing(true)
          }
        }

        setStream(mediaStream)
      } catch (err) {
        console.error("Error accessing camera:", err)
        if (mounted) {
          setError("Could not access camera. Please ensure camera permissions are granted.")
          setIsCapturing(false)
        }
      }
    }

    initCamera()

    // Clean up function
    return () => {
      mounted = false
      if (stream) {
        stream.getTracks().forEach((track) => track.stop())
      }
    }
  }, []) // Empty dependency array - only run on mount/unmount

  return (
    <div className="space-y-4">
      <div className="relative overflow-hidden rounded-md bg-muted">
        {error && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/10 p-4 text-center">
            <div className="rounded-md bg-white p-4 shadow-lg">
              <p className="text-red-500">{error}</p>
              <Button onClick={startCamera} className="mt-2" variant="outline">
                <RefreshCw className="mr-2 h-4 w-4" />
                Retry
              </Button>
            </div>
          </div>
        )}

        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className={`h-auto w-full ${isCapturing ? "block" : "hidden"}`}
        />

        <canvas ref={canvasRef} className="hidden" />

        {!isCapturing && !error && (
          <div className="flex h-[300px] items-center justify-center">
            <Button onClick={startCamera}>
              <Camera className="mr-2 h-4 w-4" />
              Start Camera
            </Button>
          </div>
        )}
      </div>

      {isCapturing && (
        <div className="flex justify-center">
          <Button onClick={captureImage}>
            <Camera className="mr-2 h-4 w-4" />
            Capture Image
          </Button>
        </div>
      )}
    </div>
  )
}
