// Import face-api.js
import * as faceapi from "face-api.js"

// Flag to track if models are loaded
let modelsLoaded = false

// Update the loadModels function to use a different approach for loading models
export const loadModels = async () => {
  if (modelsLoaded) return

  try {
    // Check if we're in a browser environment
    if (typeof window === "undefined") {
      throw new Error("Face recognition requires a browser environment")
    }

    // Use CDN URLs for the models instead of local files
    const MODEL_URL = "https://justadudewhohacks.github.io/face-api.js/models"

    // Load the required models
    await Promise.all([
      faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
      faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
    ])

    modelsLoaded = true
    console.log("Face-api models loaded successfully")
  } catch (error) {
    console.error("Error loading face-api models:", error)
    throw new Error("Failed to load face recognition models")
  }
}

// Update the detectFaces function to return the correct format
export const detectFaces = async (imageSrc: string) => {
  if (!modelsLoaded) {
    await loadModels()
  }

  try {
    // Create an HTML image element
    const img = await createImageElement(imageSrc)

    // Detect all faces with landmarks
    const detections = await faceapi.detectAllFaces(img).withFaceLandmarks()

    // Convert to a simpler format with box coordinates
    return detections.map((detection) => ({
      box: {
        x: detection.detection.box.x,
        y: detection.detection.box.y,
        width: detection.detection.box.width,
        height: detection.detection.box.height,
      },
    }))
  } catch (error) {
    console.error("Error detecting faces:", error)
    return []
  }
}

/**
 * Create a face descriptor from an image
 */
export const createFaceDescriptor = async (imageSrc: string) => {
  if (!modelsLoaded) {
    await loadModels()
  }

  try {
    // Create an HTML image element
    const img = await createImageElement(imageSrc)

    // Detect all faces with landmarks and descriptors
    const detections = await faceapi.detectAllFaces(img).withFaceLandmarks().withFaceDescriptors()

    // We only want one face for registration
    if (detections.length !== 1) {
      console.error(`Expected 1 face, found ${detections.length}`)
      return null
    }

    // Return the face descriptor
    return detections[0].descriptor
  } catch (error) {
    console.error("Error creating face descriptor:", error)
    return null
  }
}

/**
 * Compare two face descriptors and return similarity score
 */
export const compareFaces = (descriptor1: Float32Array, descriptor2: Float32Array) => {
  try {
    // Calculate Euclidean distance between descriptors
    const distance = faceapi.euclideanDistance(descriptor1, descriptor2)

    // Convert distance to similarity (1 - distance)
    // Lower distance means higher similarity
    const similarity = 1 - distance

    return similarity
  } catch (error) {
    console.error("Error comparing faces:", error)
    return 0
  }
}

/**
 * Helper function to create an image element from a source
 */
const createImageElement = (src: string): Promise<HTMLImageElement> => {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.crossOrigin = "anonymous"
    img.src = src
    img.onload = () => resolve(img)
    img.onerror = (err) => reject(err)
  })
}
